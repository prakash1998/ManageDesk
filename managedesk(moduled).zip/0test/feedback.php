<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?> 
    </head>
    <body>
        <div class="container-fluid">
            <?php require("../0moduled/header.php"); ?>
            <?php require("../0moduled/main_navigation_bar.php"); ?>
            <div class="container-fluid">
                <div class="col-md-12 col-xs-12">
                    <?php require("../0moduled/feedback_form.php"); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <?php require("../0moduled/footer.php"); ?>
                </div>
            </div>
        </div>
    </body>
</html>