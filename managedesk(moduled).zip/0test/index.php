<!DOCTYPE html>
<html lang="en">
    <head>
        <title>OM SECURITY SERVICES</title>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?> 
    </head>

    <body>
        <div class="container-fluid">
            <?php require("../0moduled/header.php"); ?>
            <?php require("../0moduled/main_navigation_bar.php"); ?>
            
            <div class="container-fluid">
                <div class="row" style="background-color:lightpink;">
                    <div class="col-md-7 col-xs-12" >
                        <?php require("../0moduled/welcome_to_omsecurity.php"); ?>
                    </div>
                    <div class="col-md-5 col-xs-12" style="background-color:white">
                        <?php require("../0moduled/forms/login_form.php"); ?>
                    </div>
                </div>
            </div>

            <div class = "row">
                <div class="col-xs-12" align="center">
                    <?php require("../0moduled/our_clients.php"); ?>
                </div>
            </div> 
            <div class="row">
                <div class="col-xs-12">
                    <?php require("../0moduled/about_us.php"); ?>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-12">
                    <?php require("../0moduled/footer.php"); ?>
                </div>
            </div>
        </div>
    </body>
</html>