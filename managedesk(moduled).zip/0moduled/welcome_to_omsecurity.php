<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?> 
    </head>
    <body>
        <div  align="justify">
            <h2>Welcome to Om Security and Service</h2>
            <p>              M/s.  Om Security & Services is managed by a team of professionals having wide and varied experience. The organization is totally committed towards achieving excellence in providing quality services to our valued customers.  The aim of our service is to relieve the management completely of all security and allied problems by providing honest, loyal and well trained staff.Mr. B. S. Rana, Ex Defence Officer Chairman of company a known name in the security industry has a Long experience in the Security field and has Been successful in carving out services which are cost effective and above all reliable and trust worthy. Within a 15 years Om Security Services touched the heights of prosperity and earned the goodwill of the clients
            </p>
        </div>
    </body>
</html>