<!DOCTYPE html>
<html lang="en">
    <head>
        <title>LogIn Form</title>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?>   
    </head>

    <body>
        <div  class="lo" align="center">
            <form >
                <div class="form-group col-md-12">
                    <label for="select_login_type">Login Type:</label>
                    <select class="form-control" id="se" >
                        <option value="Guard">Management</option>
                        <option value="Customer">Customer</option>
                        <option value="Admin">Admin</option>
                        <option value="HR manager">HR manager</option>
                    </select>



                    <label for="select_login_type">Id:</label>
                    <input type="text" name="un" placeholder="username" class="form-control" id="u_name">

                    <label for="select_login_type">password:</label>
                    <input type="password" name="ps" placeholder="password" class="form-control" id="pwd">
                </div>
                <br>

                <button id="subh" class="btn btn-primary btn-block">Login</button>
                <h5><a href="register.html">New? Register Here</a></h5>

            </form>
        </div>

    </body>
</html>