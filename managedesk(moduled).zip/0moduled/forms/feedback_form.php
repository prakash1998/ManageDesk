<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Feedback Form</title>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?>   
    </head>

    <body>
        <div class="feed">
            <form>
                <b><h1><label>Feedback Form</label></h1></b><br><br>
                <b><label>Name of Company :</label></b>
                <input type="text" placeholder="Company Name"  id="cname"><br>
                <b><label>Email-id:</label></b>
                <input type="text" placeholder="Email-id"  id="eid"><br>
                <b><label>Service:</label></b>
                <select  id="sop">
                    <option>Corporate Service</option>
                    <option>Industrial service</option>
                    <option>Pricate investigation</option>
                    <option>Event Security</option>
                    <option>Dog Squad</option>
                    <option>Bodyguard</option>
                </select><br><br>
                <b><label>Rating</label></b><br>
                <input type="radio" name="r6" >1
                <input type="radio" name="r6" >2
                <input type="radio" name="r6" >3
                <input type="radio" name="r6" >4
                <input type="radio" name="r6" >5<br>
                <b>Remarks :</b><br>
                <textarea rows="5" cols="40" ></textarea><br><br><br>
                <button  id="submi">Submit</button><br><br>
            </form>
        </div>
    </body>
</html>