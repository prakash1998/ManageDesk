<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?>   
    </head>

    <body>
        <div   style="margin-bottom: 10px;"class="resume" align="center">
            <h1>Upload your Resume</h1>
            <form >
                <label style="float: left" for="select_login_type">Fullname:</label>
                <input type="text" name="nam" placeholder="Name" class="form-control" id="name">
                <label style="float: left;margin-top: 3px;" for="select_login_type">Email-id:</label>
                <input type="text" name="eid" placeholder="Email id" class="form-control" id="e_id">
                <label style="float: left;margin-top: 3px;" for="select_login_type">Contact:</label>
                <input type="text" name="co" placeholder="Contact" class="form-control" id="phone">
                <label style="float: left;margin-top: 3px;"> Upload Resume</label> 
                <input type="file" id="filee" class="form-control">
                <br>

                <button  style="width:200px; "id="regi" class="btn btn-primary btn-block">Send</button>
            </form>
        </div>
    </body>
</html>