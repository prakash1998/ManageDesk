<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Registration Form</title>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?>   
    </head>

    <body>
        <div style="background-color: burlywood;margin-top: 10px;" class="lo" align="center">
            <form >
                <div class="form-group col-md-12">
                    <h3  class="text-center" style="text-transform: uppercase;padding-bottom: 10px;"> <b>Client Registration</b></h3>
                    <label style="float: left" for="select_login_type">Fullname:</label>
                    <input type="text" name="nam" placeholder="Name" class="form-control" id="name">
                    <label style="float: left" for="select_login_type">Email-id:</label>
                    <input type="text" name="eid" placeholder="Email id" class="form-control" id="e_id">
                    <label style="float: left" for="select_login_type">Contact:</label>
                    <input type="text" name="co" placeholder="Contact" class="form-control" id="phone">
                    <label style="float: left" for="select_login_type">Organization name:</label>
                    <input type="text" name="on" placeholder="Organization's name" class="form-control" id="o_name">
                    <label style="float: left" for="select_login_type">Username:</label>
                    <input type="text" name="un" placeholder="username" class="form-control" id="u_namer">
                    <label style="float: left" for="select_login_type">password:</label>
                    <input type="password" name="ps" placeholder="password" class="form-control" id="pwdr">
                </div>
                <br>
                <button  style="width:200px; "id="regi" class="btn btn-primary btn-block">Register</button>
                <h5><a href="index.html">already registered ? login here</a></h5>
            </form>
        </div>

    </body>
</html>