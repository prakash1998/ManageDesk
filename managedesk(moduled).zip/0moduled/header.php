<!DOCTYPE html>
<html lang="en">
    <head>
        <title>OM SECURITY SERVICES</title>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?> 
    </head>
    <body>
        <div class="row">
            <div class="col-xs-12">
                <div class="ino"> 
                    <h1><b>OM SECURITY AND SERVICES</b></h1>
                    <h2>ISO CERTIFIED 9001:2008</h2>
                </div>
            </div>
        </div>
    </body>
</html>
