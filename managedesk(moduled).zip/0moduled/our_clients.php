<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?> 
    </head>
    
    <body>
        <div class="client">
            <h1 class="alert-danger" style="color: black;font-size: 30px">Our Clients</h1>
            <img src="../Assets/Images/cl1.PNG"  class="img-thumbnail">
            <img src="../Assets/Images/cl2.PNG"  class="img-thumbnail">
            <img src="../Assets/Images/cl3.PNG" class="img-thumbnail">
            <img src="../Assets/Images/cl4.png" class="img-thumbnail">
            <img src="../Assets/Images/cl5.png" class="img-thumbnail">
            <img src="../Assets/Images/cl6.png" class="img-thumbnail">
        </div>
    </body>
</html>
