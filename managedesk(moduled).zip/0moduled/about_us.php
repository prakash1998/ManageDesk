<!DOCTYPE html>
<html lang="en">
    <head>
        <title>OM SECURITY SERVICES</title>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?> 
    </head>
    <body>
        <div class="info" >
            <h2><b>About Us</b></h2>
            <p align="justify">Security services to government institutions, semi government organizations, large and small scale industries, private and public enterprises, factories, also do provide our Armed Guards as per eligibility in a place or state.For reaching to a level with relentless services over years make us one of premier and clients flavors.Top management possess guard experience in the field of Admin/ Operation both to steer the ship and sail smooth.Expertise in the field with good coordination of Ex. Army, Ex Police, Civilised civilian bring dramatic result and change in prevailing.Good governance with quality leaders is growing across with wide band width along with good net work which generally makes a strong chain and provides a Pillar kind stability for both to us as well to clients.Combinations of expertees have set up status in all premier locations to receive work in any challenging situation. 
            </p>
        </div>
    </body>
</html>
