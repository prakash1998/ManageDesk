<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require("../bootstrap/bootstrap_cdn.php"); ?> 
    </head>

    <body>
        <div  style="background-color: maroon" class="foo" >
            <ul  style="display: inline-block;">
                <li style="display: inline-block"><a href="#">Home<span class="sr-only">(current)</span></a></li>
                <li style="display: inline-block"><a href="#">Career</a></li>
                <li style="display: inline-block"><a href="#">Services</a></li>
                <li style="display: inline-block"><a href="#">Feedback</a></li>
                <li style="display: inline-block"><a href="#">Contact Us</a></li>
                <li style="display: inline-block"><a href="#">Request for Services</a></li>
            </ul>
        </div>
    </body>
</html>
